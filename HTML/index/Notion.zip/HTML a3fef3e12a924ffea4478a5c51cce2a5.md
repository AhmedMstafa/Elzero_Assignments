# HTML

# What Is HTML?

- Hyper text Markup Language
- The Language To Build The Web
- Ship + Building + Skeleton

# Versions

- 4
- 5

- Why  Learn HTML
    - Front-End Developer
    - Back-End Developer
    - Mobile Developer
    - Reports
- **[Why do people name their files index.html?](https://stackoverflow.com/questions/32408259/why-do-people-name-their-files-index-html)**
    
    [Why do people name their files index.html?](https://stackoverflow.com/questions/32408259/why-do-people-name-their-files-index-html)
    
- What is metadata ?
    - Data that provide information about other data.
    - Metadata summarizes basic information about data, making finding & working with particular instances of data easier.
    - Metadata can be created manually to be more accurate, or automatically and contain more basic information.
    
- comment
    
    ```html
    <!-- This Is Comment -->
    ```
    
    ```html
    <!-- 
    Comment Line One 
    Comment Line Two                 
    Comment Line Three 
    -->
    ```
    
- DOCTYPE?
    
    is not an HTML tag. It is an "information" to the browser about what document type to expect.
    
    In HTML 5, the declaration is simple:
    
    ```html
    <!doctype html>
    ```
    
- List
    
    ```html
    <ol type="A" | start="1" | type="a" | type="i" |value="" >
    <li>Name</li>
    <li>Address</li>
    <li>id</li>
    </ol>
    ```
    
    ```html
    <ol>
    <li value="50">Name</li>
    <li>Address</li>
    <li>id</li>
    </ol>
    ```
    
- entities
    
    [Complete list of HTML entities - FreeFormatter.com](https://www.freeformatter.com/html-entities.html)
    
- Table Attributes
    
    ```html
    <table border="1" cellpadding="10" cellspacing="0" >
    ```
    
- Semantic Elements
    
    ![https://bunchmediacom.files.wordpress.com/2021/06/figure01.png](https://bunchmediacom.files.wordpress.com/2021/06/figure01.png)
    
    [HTML5 Semantic Elements: Explained](https://bunch-media.com/2021/06/03/html5-semantic-elements-explained/)
    
- MME Type!
    
    [W3cubDocs](https://docs.w3cub.com/http/basics_of_http/mime_types/complete_list_of_mime_types.html)
    
    ```html
    <audio controls>
    <source src="media/one_way_ticket.mp3" type="audio/mpeg">
    <source src="media/one_way_ticket.mp3" type="audio/mpeg">
    <source src="media/one_way_ticket.mp3" type="audio/mpeg">
      your Browser Does Not Support Audio Tags
    </audio>
    ```
    
- subtitles in video
    
    ```html
    <track src="my_file_En.vtt" kind="subtitles" srclang="En" label="English" >
          <track src="my_file_it.vtt" kind="subtitles" srclang="It" label="Italic" >
    ```
    
- Input
    
    ```html
    <form action="" method="">
    <label></label>
    <input type="text" placeholder="Uername">
    <label></label>
    <input type="password" >
    <input type="submit" required  placeholder="Write a Comlex Password">
    <input type="email" required  placeholder="Write a Valid Email">
    <input type="hidden" >
    <input type="reset" >
    <input type="color" name="color">
    <input type="range" min="" max="" step="" value="" >
    <input type="number" min="" max="" step="" value="" >
    
    <input type="text" placeholder="Uername" value="Ahmed" readonly />
    <input type="text" placeholder="Uername" value="Ahmed" disabled />
    <input type="text" placeholder="Uername" value="Ahmed" autofocus/>
    <input type="password" placeholder="pass" minlength="10" maxlength />
    </form>
    ```
    
    ```html
    
    <input id="win" type="radio" name="os" value="Windos" checked>
    <label for="win">Windos</label>
    <input id="mac" type="radio" name="os" value="mac">
    <label for="mac">mac</label>
    <input id="Lin" type="radio" name="os" value="Linux" >
    <label for="lin">linux</label>
    ```
    
    ```html
    <label for="book">Windos</label>
    <select id="book" name="book" multiple>
    <optgroup label="Romantic books">
    <option value="1" selected>Book 1</option>
    <option value="2">Book 2</option>
    <option value="3">Book 3</option>
    <option value="4">Book 4</option>
    </optgroup>
    <optgroup label="Police Books">
    <option value="5">Book 1</option>
    <option value="6">Book 2</option>
    <option value="7">Book 3</option>
    <option value="8">Book 4</option>
    </optgroup>
    </select>
    ```
    
    ```html
    <texteara name="" id="" cols="" rows="" ></textarea>Qu
    
    ```
    
    ![Untitled](HTML%20a3fef3e12a924ffea4478a5c51cce2a5/Untitled.png)
    
    ```html
    <label >Upload</label>
    <input type="file"  >
    <label >Search</label>
    <input type="search"  >
    <label >Url</label>
    <input type="url"  >
    <label >Date</label>
    <input type="date">
    <label >Month</label>
    <input type="month"  >
    <label >Time</label>
    <input type="time"  >
    <label >Datalist</label>
    <input list="progrmnimg"  >
    <datalist id="progrmnimg">
    <option value="1">
    <option value="2">
    <option value="3">
    <option value="4">
    </datalist>
    ```
    
- ARIA
    
    > Accessible  reach internet application
    > 
    
    ```html
    <div 
    role="checkbox" 
    aria-checked="true" 
    tabindex="0 
    aria-labelledby="plane1">plane One</div>
    <label id="plane1">plane one label</label>
    ```
    
- search for
    - lighthouse
    - contrast ratio
    - Accessibility
- code on code
    
    ```html
    <div>
          <pre style="background-color: black">
                <code style="color: white;">
                     
                    &lt;input type="sumbit"&gt;
        
                    &lt;h1&gt;
        
                    &lt;article&gt;
        
                    &lt;p&gt;
        
                    &lt;meta lang="en"&gt;
        
                    &lt;&excl;&#45;&#45;10 to 20&#45;&#45;&gt;
        
                    &lt;div tabindex="0"&gt;
        
                    &lt;&excl;&#45;&#45;ARIA: Accessible  Reach Internet Application&#45;&#45;&gt;
        
                </code>
            </pre>
        </div>
    ```
    

[html tags](https://www.notion.so/582523674b1d4a3487b35390952dcf4f)

[attributes](https://www.notion.so/e7de32372a894df4a782c20959aacc51)